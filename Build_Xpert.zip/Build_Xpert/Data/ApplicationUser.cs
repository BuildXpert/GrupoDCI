using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace DisenoDCI.Data
{
    public class ApplicationUser : IdentityUser
    {

        [Required]
        [StringLength(100)]
        public string FullName { get; set; } = string.Empty;

        [Required]
        public string Role { get; set; } = "Cliente"; 
    }
}
