﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DisenoDCI.Migrations
{
    /// <inheritdoc />
    public partial class Properties : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Suppliers");

            migrationBuilder.RenameColumn(
                name: "TotalArea",
                table: "Projects",
                newName: "LandSize");

            migrationBuilder.RenameColumn(
                name: "Location",
                table: "Projects",
                newName: "Province");

            migrationBuilder.RenameColumn(
                name: "HouseType",
                table: "Projects",
                newName: "ConstructionType");

            migrationBuilder.RenameColumn(
                name: "Garage",
                table: "Projects",
                newName: "Canton");

            migrationBuilder.AddColumn<double>(
                name: "ConstructionSize",
                table: "Projects",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<int>(
                name: "Floors",
                table: "Projects",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "GarageCapacity",
                table: "Projects",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<bool>(
                name: "HasGarage",
                table: "Projects",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "IsCondominium",
                table: "Projects",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<decimal>(
                name: "Price",
                table: "Projects",
                type: "decimal(18,2)",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.CreateTable(
                name: "Properties",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Status = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ConstructionType = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Province = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Canton = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ConstructionSize = table.Column<double>(type: "float", nullable: false),
                    LandSize = table.Column<double>(type: "float", nullable: false),
                    Bedrooms = table.Column<int>(type: "int", nullable: false),
                    Bathrooms = table.Column<int>(type: "int", nullable: false),
                    Price = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Floors = table.Column<int>(type: "int", nullable: false),
                    HasGarage = table.Column<bool>(type: "bit", nullable: false),
                    GarageCapacity = table.Column<int>(type: "int", nullable: false),
                    IsCondominium = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Properties", x => x.Id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Properties");

            migrationBuilder.DropColumn(
                name: "ConstructionSize",
                table: "Projects");

            migrationBuilder.DropColumn(
                name: "Floors",
                table: "Projects");

            migrationBuilder.DropColumn(
                name: "GarageCapacity",
                table: "Projects");

            migrationBuilder.DropColumn(
                name: "HasGarage",
                table: "Projects");

            migrationBuilder.DropColumn(
                name: "IsCondominium",
                table: "Projects");

            migrationBuilder.DropColumn(
                name: "Price",
                table: "Projects");

            migrationBuilder.RenameColumn(
                name: "Province",
                table: "Projects",
                newName: "Location");

            migrationBuilder.RenameColumn(
                name: "LandSize",
                table: "Projects",
                newName: "TotalArea");

            migrationBuilder.RenameColumn(
                name: "ConstructionType",
                table: "Projects",
                newName: "HouseType");

            migrationBuilder.RenameColumn(
                name: "Canton",
                table: "Projects",
                newName: "Garage");

            migrationBuilder.CreateTable(
                name: "Suppliers",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ContactEmail = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ContactPhone = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ServiceType = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Suppliers", x => x.Id);
                });
        }
    }
}
