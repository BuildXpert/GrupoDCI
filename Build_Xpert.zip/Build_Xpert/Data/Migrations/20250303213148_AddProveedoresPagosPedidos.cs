﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DisenoDCI.Migrations
{
    /// <inheritdoc />
    public partial class AddProveedoresPagosPedidos : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_PedidoProveedor_Proveedores_ProveedorId",
                table: "PedidoProveedor");

            migrationBuilder.DropPrimaryKey(
                name: "PK_PedidoProveedor",
                table: "PedidoProveedor");

            migrationBuilder.RenameTable(
                name: "PedidoProveedor",
                newName: "Pedidos");

            migrationBuilder.RenameIndex(
                name: "IX_PedidoProveedor_ProveedorId",
                table: "Pedidos",
                newName: "IX_Pedidos_ProveedorId");

            migrationBuilder.AddColumn<DateTime>(
                name: "Fecha",
                table: "Pedidos",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddPrimaryKey(
                name: "PK_Pedidos",
                table: "Pedidos",
                column: "Id");

            migrationBuilder.CreateTable(
                name: "Pagos",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProveedorId = table.Column<int>(type: "int", nullable: false),
                    Monto = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Fecha = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Pagos", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Pagos_Proveedores_ProveedorId",
                        column: x => x.ProveedorId,
                        principalTable: "Proveedores",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Pagos_ProveedorId",
                table: "Pagos",
                column: "ProveedorId");

            migrationBuilder.AddForeignKey(
                name: "FK_Pedidos_Proveedores_ProveedorId",
                table: "Pedidos",
                column: "ProveedorId",
                principalTable: "Proveedores",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Pedidos_Proveedores_ProveedorId",
                table: "Pedidos");

            migrationBuilder.DropTable(
                name: "Pagos");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Pedidos",
                table: "Pedidos");

            migrationBuilder.DropColumn(
                name: "Fecha",
                table: "Pedidos");

            migrationBuilder.RenameTable(
                name: "Pedidos",
                newName: "PedidoProveedor");

            migrationBuilder.RenameIndex(
                name: "IX_Pedidos_ProveedorId",
                table: "PedidoProveedor",
                newName: "IX_PedidoProveedor_ProveedorId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_PedidoProveedor",
                table: "PedidoProveedor",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_PedidoProveedor_Proveedores_ProveedorId",
                table: "PedidoProveedor",
                column: "ProveedorId",
                principalTable: "Proveedores",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
